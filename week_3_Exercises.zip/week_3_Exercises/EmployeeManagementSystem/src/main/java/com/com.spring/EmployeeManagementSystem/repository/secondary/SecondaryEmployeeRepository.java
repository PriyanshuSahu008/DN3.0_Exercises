package com.amlan.EmployeeManagementSystem.repository.secondary;

import com.amlan.EmployeeManagementSystem.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecondaryEmployeeRepository extends JpaRepository<Employee, Long> {

}

