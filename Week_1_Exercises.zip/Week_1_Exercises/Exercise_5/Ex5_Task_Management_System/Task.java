package Ex5_Task_Management_System;


public class Task {
    private int taskId;
    private String taskName;
    private String status;

    public Task(int taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public int getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public class Node {
        private Task task;
        private Node next;

        public Node(Task task) {
            this.task = task;
            this.next = null;
        }

        public Task getTask() {
            return task;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }
    }


    public class LinkedList {
        private Node head;

        public LinkedList() {
            this.head = null;
        }

        public void addTask(Task task) {
            Node node = new Node(task);
            if (head == null) {
                head = node;
            } else {
                Node current = head;
                while (current.getNext() != null) {
                    current = current.getNext();
                }
                current.setNext(node);
            }
        }

        public Task searchTask(int taskId) {
            Node current = head;
            while (current != null) {
                if (current.getTask().getTaskId() == taskId) {
                    return current.getTask();
                }
                current = current.getNext();
            }
            return null;
        }


        public void traverse() {
            Node current = head;
            while (current != null) {
                System.out.println("Task ID: " + current.getTask().getTaskId());
                System.out.println("Task Name: " + current.getTask().getTaskName());
                System.out.println("Status: " + current.getTask().getStatus());
                System.out.println();
                current = current.getNext();
            }
        }


        public void deleteTask(int taskId) {
            if (head == null) {
                return;
            }
            if (head.getTask().getTaskId() == taskId) {
                head = head.getNext();
                return;
            }
            Node current = head;
            while (current.getNext() != null) {
                if (current.getNext().getTask().getTaskId() == taskId) {
                    current.setNext(current.getNext().getNext());
                    return;
                }
                current = current.getNext();
            }
        }
    }
}

