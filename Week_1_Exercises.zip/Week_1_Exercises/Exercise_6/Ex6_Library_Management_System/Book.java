package Ex6_Library_Management_System;

import java.util.ArrayList;
import java.util.List;

public class Book {
    private int bookId;
    private String title;
    private String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }


    class Bookshelf {
        private List<Book> books;

        public Bookshelf() {
            this.books = new ArrayList<>();
        }

        public void addBook(Book book) {
            books.add(book);
        }

        public Book linearSearchByTitle(String title) {
            for (Book book : books) {
                if (book.getTitle().equals(title)) {
                    return book;
                }
            }
            return null;
        }

        public Book binarySearchByTitle(String title) {
            int low = 0;
            int high = books.size() - 1;

            while (low <= high) {
                int mid = (low + high) / 2;
                Book midBook = books.get(mid);

                if (midBook.getTitle().equals(title)) {
                    return midBook;
                } else if (midBook.getTitle().compareTo(title) < 0) {
                    low = mid + 1;
                } else {
                    high = mid - 1;
                }
            }
            return null;
        }

        public void sortBooksByTitle() {
            books.sort((b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        }
    }

    public static void main(String[] args) {

    }
}



