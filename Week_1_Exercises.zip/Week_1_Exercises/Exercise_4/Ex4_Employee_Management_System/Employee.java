package Ex4_Employee_Management_System;

public class Employee {
    private int employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }


    class EmployeeDatabase {
        private Employee[] employees;
        private int size;

        public EmployeeDatabase(int capacity) {
            this.employees = new Employee[capacity];
            this.size = 0;
        }

        public void addEmployee(Employee employee) {
            if (size < employees.length) {
                employees[size] = employee;
                size++;
            } else {
                System.out.println("Database is full. Cannot add more employees.");
            }
        }

        public Employee searchEmployee(int employeeId) {
            for (int i = 0; i < size; i++) {
                if (employees[i].getEmployeeId() == employeeId) {
                    return employees[i];
                }
            }
            return null;
        }

        public void traverseEmployees() {
            for (int i = 0; i < size; i++) {
                System.out.println(employees[i]);
            }
        }

        public void deleteEmployee(int employeeId) {
            int index = -1;
            for (int i = 0; i < size; i++) {
                if (employees[i].getEmployeeId() == employeeId) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                for (int i = index; i < size - 1; i++) {
                    employees[i] = employees[i + 1];
                }
                size--;
            } else {
                System.out.println("Employee not found.");
            }
        }
    }

    public static void main(String[] args) {

    }

}

