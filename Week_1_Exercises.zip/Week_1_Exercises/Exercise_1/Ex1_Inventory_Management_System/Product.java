package Ex1_Inventory_Management_System;

import java.util.HashMap;
import java.util.Map;

public class Product {
    private int productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(int productId, String productName, int quantity, double price){
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }



    public class Inventory {
        private Map<Integer, Product> products;

        public Inventory() {
            this.products = new HashMap<>();
        }
        public void addProduct(Product product) {
            products.put(product.getProductId(), product);
        }
        public void updateProduct(int id, Product updatedProduct) {
            if (products.containsKey(id)) {
                products.put(id, updatedProduct);
            }
        }
        public void deleteProduct(int id) {
            products.remove(id);
        }
        public void displayProducts() {
            for (Product product : products.values()) {
                System.out.println("ID: " + product.getProductId());
                System.out.println("Name: " + product.getProductName());
                System.out.println("Price: " + product.getPrice());
                System.out.println("Quantity: " + product.getQuantity());
                System.out.println();
            }
        }

        // Method to get a product by ID
        public Product getProduct(int id) {
            return products.get(id);
        }
    }

    public static void main(String[] args) {

    }
}
