package com.AmlanDash.library.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    @Around("execution(* com.AmlanDash.library.service.*.*(..))")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();

        // Log before method execution
        System.out.println("Before method: " + joinPoint.getSignature().toShortString());

        // Proceed with the method call
        Object result = joinPoint.proceed();

        long elapsedTime = System.currentTimeMillis() - start;

        // Log after method execution
        System.out.println("After method: " + joinPoint.getSignature().toShortString());

        return result;
    }
}

